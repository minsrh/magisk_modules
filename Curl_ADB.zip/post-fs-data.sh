#!/system/bin/sh
chmod 0755 /system/bin/curl